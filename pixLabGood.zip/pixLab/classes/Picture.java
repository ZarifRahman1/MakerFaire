import java.awt.*;
import java.awt.desktop.SystemEventListener;
import java.awt.font.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.text.*;
import java.util.*;
import java.util.List;
public class Picture extends SimplePicture {
  public static void main(String[] args)
  {
    Picture yourImage = new Picture("image.png");//replace the "image.png" with "filename.png" make sure there are still quotes
    //your image should be located in
    // "FolderLocation"\pixLabGood(the folder you downloaded)\out\production\images
    //or the code will not work
    yourImage.makeByColor();
    yourImage.explore();
  }
  public void makeByColor(){//This is the class that converts the picture into a color by number
    Pixel[][] eagle = this.getPixels2D();
    //These are the assets it uses to convert to blanks with numbers
    Picture one= new Picture("one.png");
    //one=one.scale(0.1,0.1);
    Picture two= new Picture("two.png");
    //two=two.scale(0.1,0.1);
    Picture three= new Picture("three.png");
    //three=three.scale(0.1,0.1);
    Picture four= new Picture("four.png");
    // four=four.scale(0.1,0.1);
    Picture five= new Picture("five.png");
    // five=five.scale(0.1,0.1);
    Picture six= new Picture("six.png");
    // six=six.scale(0.1,0.1);
    Picture seven= new Picture("seven.png");
    // seven=seven.scale(0.1,0.1);
    Picture eight= new Picture("eight.png");
    eight=eight.scale(0.1,0.1);
    Picture nine= new Picture("nine.png");
    //  nine=nine.scale(0.1,0.1);
    //This defines the colors it will convert
    Color white= new Color(255,255,255);
    Color black= new Color(0,0,0);
    Color lightGray= new Color(201,201,201);
    Color lightBrown= new Color(77,55,0);
    Color lightPurpleGray= new Color(208,182,212);
    Color purpleGray= new Color(178,132,184);
    Color yellow= new Color(255,242,0);
    Color darkBrown= new Color(48,38,8);
    Color blue= new Color(161,162,255);
    int rowCounter=0;
    int colCounter=0;

    //this iterates through all the pixels within the image
    //and if the colors match it will convert to a blank
    for(int row=0;row<eagle.length-1;row+=100){
      for(int col=0;col<eagle[0].length-1;col+=100) {
        Color pixColor= eagle[row][col].getColor();
        if (white.equals(pixColor)) {
          this.copy(one,row,col);
        }
        if (black.equals(pixColor)) {
          this.copy(two,row,col);
        }
        if (lightGray.equals(pixColor)) {
          this.copy(three,row,col);
        }
        if (lightBrown.equals(pixColor)) {
          this.copy(four,row,col);
        }
        if (lightPurpleGray.equals(pixColor)) {
          this.copy(five,row,col);
        }
        if (purpleGray.equals(pixColor)) {
          this.copy(six,row,col);
        }
        if (yellow.equals(pixColor)) {
          this.copy(seven,row,col);
        }
        if (darkBrown.equals(pixColor)) {
          this.copy(eight,row,col);
        }
        if (blue.equals(pixColor)) {
          this.copy(nine,row,col);
        }
        System.out.println("Row: "+rowCounter+" | Col: "+colCounter);//progress bar
        colCounter++;

      }
      System.out.println("Row: "+rowCounter+" | Col: "+colCounter);//progress bar
      rowCounter++;
      colCounter=0;

    }
    //this is the output
    //It will be located within the same folder as your image and be called "outputImage.png"
    this.write("outputImage.png");

  }
  ///////////////////// constructors //////////////////////////////////
  
  /**
   * Constructor that takes no arguments 
   */
  public Picture ()
  {
    /* not needed but use it to show students the implicit call to super()
     * child constructors always call a parent constructor 
     */
    super();  
  }
  
  /**
   * Constructor that takes a file name and creates the picture 
   * @param fileName the name of the file to create the picture from
   */
  public Picture(String fileName)
  {
    // let the parent class handle this fileName
    super(fileName);
  }
  
  /**
   * Constructor that takes the width and height
   * @param height the height of the desired picture
   * @param width the width of the desired picture
   */
  public Picture(int height, int width)
  {
    // let the parent class handle this width and height
    super(width,height);
  }
  
  /**
   * Constructor that takes a picture and creates a 
   * copy of that picture
   * @param copyPicture the picture to copy
   */
  public Picture(Picture copyPicture)
  {
    // let the parent class do the copy
    super(copyPicture);
  }
  
  /**
   * Constructor that takes a buffered image
   * @param image the buffered image to use
   */
  public Picture(BufferedImage image)
  {
    super(image);
  }
  
  ////////////////////// methods ///////////////////////////////////////
  
  /**
   * Method to return a string with information about this picture.
   * @return a string with information about the picture such as fileName,
   * height and width.
   */
  public String toString()
  {
    String output = "Picture, filename " + getFileName() + 
      " height " + getHeight() 
      + " width " + getWidth();
    return output;
    
  }


  public void copy(Picture fromPic,
                 int startRow, int startCol)
  {
    Pixel fromPixel = null;
    Pixel toPixel = null;
    Pixel[][] toPixels = this.getPixels2D();
    Pixel[][] fromPixels = fromPic.getPixels2D();
    for (int fromRow = 0, toRow = startRow;
         fromRow < fromPixels.length &&
         toRow < toPixels.length;
         fromRow++, toRow++)
    {
      for (int fromCol = 0, toCol = startCol;
           fromCol < fromPixels[0].length &&
           toCol < toPixels[0].length;
           fromCol++, toCol++)
      {
        fromPixel = fromPixels[fromRow][fromCol];
        toPixel = toPixels[toRow][toCol];
        toPixel.setColor(fromPixel.getColor());
      }
    }
  }

  
} // this is the end of class Picture, put all new methods before this
